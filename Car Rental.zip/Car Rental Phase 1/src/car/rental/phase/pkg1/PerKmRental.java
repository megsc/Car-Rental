/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.rental.phase.pkg1;

/**
 *
 * @author megancarlton
 */
public class PerKmRental 
{
	//class variables 
    int chargePerKm;
    int distancePerRentalKm;
    
    //constructor 
    PerKmRental()
    {
        chargePerKm = 5;
        distancePerRentalKm = 0;
    }
    
	//setters and getters 
    public PerKmRental(int journeyPerRental)
    {
        this();
        distancePerRentalKm = journeyPerRental;
    }
    
    public void setRentalKm(int rentalJourney)
    {
        distancePerRentalKm = rentalJourney;
    }
    
    public int getRentalKm()
    {
        return distancePerRentalKm;
    }
                
    public int getChargePerKm()
    {
        return distancePerRentalKm * chargePerKm;
    }
    
	
	//output details 
    public void printPerKmRental()
	{
        System.out.println("Total gross per kilometre rate charged for rental: $" + getChargePerKm());
        
    }
            
    
}
