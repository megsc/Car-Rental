
package car.rental.phase.pkg1;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Main  {

    
	  public static void main(String args[])
	  {
                //try catch statement for input errors
		try
		{
			  
                    //array of car details 
                    String[] carDets = new String[6];
                    carDets[0] = "Audi";
                    carDets[1] = "A6";
                    carDets[2] = "Jaguar";
                    carDets[3] = "X200";
                    carDets[4] = "Mercedes-Benz";
                    carDets[5] = "CL600 C200";
            
                    while (true)
                    {
                        //console menu for selecting a car by manufacturer
                        System.out.print("\nPlease select car type: " + "\n1.Audi " + "\n2.Jaguar " + "\n3.Mercedes-Benz" + "\n4.Exit" + "\n");
                        Scanner selection = new Scanner(System.in);
                        String choice = selection.nextLine();
                        int menuChoice;
                        menuChoice = Integer.parseInt(choice);
            
            
			
			//menu choice for Audi
                        if (menuChoice == 1)
                    {
			//car specs for Audi
                        Vehicle blue = new Vehicle();
                        blue.setBrand(carDets[0]);
                        blue.setModel(carDets[1]);
                        blue.setYear(2016);
                
                        //Journey details for rental 1
                        Journey blueB1 = new Journey();
                        blueB1.setTravelled(210);
                        blue.addJourney(blueB1);
                        
                        
                        //Fuel Purchase details for rental 1
                        FuelPurchase blueC1 = new FuelPurchase();
                        blueC1.setKmTrav(blue.getJourney(0).getTravelled());
                        blueC1.getFuelEcon();
                        blueC1.setFuelCost(62);
                        blueC1.setLitresFuel(75);      
                        blueC1.getAverageFuelCost();
                        blue.addFuel(blueC1);
                        
                        
                        //Rental 1 charged per KM only
                        PerKmRental blueD1 = new PerKmRental();
                        blueD1.setRentalKm(blue.getJourney(0).getTravelled());
                        blueD1.getChargePerKm();
                        blueB1.addPerKmRental(blueD1);
                        
                        
                        //Service details for rental 1 
			Service blueF1 = new Service();
			blueF1.setKmForService(blue.getJourney(0).getTravelled());
                        blueF1.getServiceKm();
                        blueF1.setCarService(true);
			blueF1.getCarService();
                        blueB1.addService(blueF1);
                        
				
			//Journey details for rental 2
                        Journey blueB2 = new Journey();
                        blueB2.setTravelled(110);
                        blue.addJourney(blueB2);
                        
                              
			//Fuel Purchase details for rental 2
                        FuelPurchase blueC2 = new FuelPurchase();
                        blueC2.setKmTrav(blue.getJourney(1).getTravelled());
                        blueC2.getFuelEcon();
                        blueC2.setFuelCost(57);
                        blueC2.setLitresFuel(67);      
                        blueC2.getAverageFuelCost();
                        blue.addFuel(blueC2);
                        
		                
			//Rental 2 charged per Day only
                        PerDayRental blueE2 = new PerDayRental();
                        blueE2.setRentalDays(3);
                        blueE2.getRentalCharge();
			blueE2.setRentalKm(blue.getJourney(1).getTravelled());
			blueE2.getRentalKm();
                        blueB2.addPerDayRental(blueE2);
                        
			
                        //Service details for rental 2 
			Service blueF2 = new Service();
			blueF2.setKmForService(blue.getJourney(1).getTravelled());
                        blueF2.getServiceKm();
                        blueF2.setCarService(true);
			blueF2.getCarService();
                        blueB2.addService(blueF2);
                        
			    
			//Ouput for rental history/rental 1 
			System.out.println("Audi Rental History: \nRental 1: ");
			blue.printVehicle();
			blue.getJourney(0).printJourney();
                        blue.getFuel(0).printFuelPurchase();
                        blueB1.getKm(0).printPerKmRental();
                        blueB1.getService(0).printServices();
                        
                        
			//Output for rental 2 
			System.out.println("\nRental 2: ");
                        blue.printVehicle();
                        blue.getJourney(1).printJourney();
                        blue.getFuel(1).printFuelPurchase();
                        blueB2.getDay(0).printPerDayRental();
                        blueB2.getService(0).printServices();

                
			//if statement to determine if vehicle can be released for new rental based on service history
                        if (blueF2.getCarService() == true)
			{
                            System.out.println("WARNING: Vehicle requires service before further rentals!");
			}
				
			else
			{
                            System.out.println("--Vehicle can be released for hire--");
			}
                        
                    }
            
                    //menu choice for Jaguar
                    else if (menuChoice == 2)
                    {
			//car specs for Jag
			Vehicle red = new Vehicle();
			red.setBrand(carDets[2]);
			red.setModel(carDets[3]);
			red.setYear(2015);
				
			//Journey details for rental 1
			Journey redB = new Journey();
			redB.setTravelled(95);
                        red.addJourney(redB);
		
			//Fuel Purchase details for rental 1
			FuelPurchase redC = new FuelPurchase();
			redC.setFuelCost(72);
			redC.setKmTrav(red.getJourney(0).getTravelled());
                        redC.getFuelEcon();
			redC.setLitresFuel(82);
			redC.getAverageFuelCost();
                        red.addFuel(redC);
				
			//Rental 1 charged per day only
			PerDayRental redD = new PerDayRental();
			redD.setRentalDays(6);
                        redD.setRentalKm(red.getJourney(0).getTravelled());
                        redD.getRentalKm();
			redD.getRentalCharge();
                        redB.addPerDayRental(redD);
				
			//Service details for rental 1 
			Service redE = new Service();
			redE.setKmForService(red.getJourney(0).getTravelled());
                        redE.getServiceKm();
			redE.setCarService(false);
                        redE.getCarService();
                        redB.addService(redE);

			//Output for rental history/rental 1 
			System.out.println("Jaguar Rental History: \nRental 1: ");
                        red.printVehicle();
                        red.getJourney(0).printJourney();
                        red.getFuel(0).printFuelPurchase();
                        redB.getDay(0).printPerDayRental();
                        redB.getService(0).printServices();
				
			//if statement to determine if vehicle can be released for new rental based on service history
			if (redE.getCarService() == true)
			{
                            System.out.println("WARNING: Vehicle requires service before further rentals!");
			}
				
			else
			{
                            System.out.println("--Vehicle can be released for hire--");
			}
				
                        }
            
			//menu choice for Mercedes-Benz
                    else if(menuChoice == 3)
                    {
                        //car specs for Merc
			Vehicle green = new Vehicle();
			green.setBrand(carDets[4]);
			green.setModel(carDets[5]);
			green.setYear(2015);

			//Journey details for rental 1
			Journey greenB1 = new Journey();
			greenB1.setTravelled(350);
                        green.addJourney(greenB1);
                        
                        //Fuel Purchase details for rental 1 
			FuelPurchase greenC1 = new FuelPurchase();
			greenC1.setKmTrav(green.getJourney(0).getTravelled());
                        greenC1.getFuelEcon();
			greenC1.setFuelCost(100);
			greenC1.setLitresFuel(100);
			greenC1.getAverageFuelCost();
                        green.addFuel(greenC1);
                        
                        //rental 1 charged per KM only
			PerKmRental greenD1 = new PerKmRental();
			greenD1.setRentalKm(green.getJourney(0).getTravelled());
			greenD1.getChargePerKm();
                        greenB1.addPerKmRental(greenD1);
                        
                        //Service details for rental 1 
			Service greenF1 = new Service();
			greenF1.setKmForService(green.getJourney(0).getTravelled());
			greenF1.setCarService(true);
                        greenF1.getCarService();
                        greenB1.addService(greenF1);
				
			//Journey details for rental 2
			Journey greenB2 = new Journey();
			greenB2.setTravelled(600);
			green.addJourney(greenB2);
		
			//Fuel Purchase details for rental 2
			FuelPurchase greenC2 = new FuelPurchase();
			greenC2.setKmTrav(green.getJourney(1).getTravelled());
                        greenC2.getFuelEcon();
			greenC2.setFuelCost(110);
			greenC2.setLitresFuel(107);
			greenC2.getAverageFuelCost();
			green.addFuel(greenC2);
				
			//rental 2 charged per Day only
			PerDayRental greenE2 = new PerDayRental();
			greenE2.setRentalDays(8);
			greenE2.setRentalKm(green.getJourney(1).getTravelled());
			greenE2.getRentalKm();
			greenE2.getRentalCharge();
                        greenB2.addPerDayRental(greenE2);
			
                        //Service details for rental 2 
                        Service greenF2 = new Service();
                        greenF2.setKmForService(green.getJourney(1).getTravelled());
                        greenF2.setCarService(true);
                        greenF2.getCarService();
                        greenB2.addService(greenF2);
                                
			//Output for rental history/rental 1 
			System.out.println("Mercedes-Benz Rental History: \nRental 1: ");
			green.printVehicle();
                        green.getJourney(0).printJourney();
                        green.getFuel(0).printFuelPurchase();
                        greenB1.getKm(0).printPerKmRental();
                        greenB1.getService(0).printServices();
			
				
			//output for rental 2 
			System.out.println("\nRental 2: ");
			green.printVehicle();
                        green.getJourney(1).printJourney();
                        green.getFuel(1).printFuelPurchase();
                        greenB2.getDay(0).printPerDayRental();
                        greenB2.getService(0).printServices();
                        
                        
                        
			//if statement to determine if vehicle can be released for new rental based on service history
			if (greenF2.getCarService() == true)
			{
                            System.out.println("WARNING: Vehicle requires service before further rentals!");
			}
				
			else 
			{
                            System.out.println("--Vehicle can be released for hire--");
			}
                            
                    }
			
			//menu choice to exit
                    else if(menuChoice == 4)
			{
				System.out.println("Bye Bye :) ");
				System.exit(0);
			}
			
			//output for invalid numeric input
                    else 
			{
				System.out.println("Oops! Try again");
			}
        
    
	  }
     
       
    }
	//invalid input error handling 
	catch (IllegalArgumentException e)
		{	
			System.out.println("Uh Oh! Something went wrong :( ");
		}
	  }
}

