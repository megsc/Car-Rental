/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.rental.phase.pkg1;

/**
 *
 * @author megancarlton
 */
public class Service 
{
    //class variable
	int kmTravelledSinceLastService;
        boolean serviceRequired;
	
	//constructor 
	Service()
	{
            kmTravelledSinceLastService = 0;
            serviceRequired = true;
	}
   
	//setters and getters 
	void setKmForService(int carService)
	{
            kmTravelledSinceLastService = carService;
	}
	
        public int getServiceKm()
        {
            return kmTravelledSinceLastService;
        }
        
        void setCarService(boolean needService)
        {
            serviceRequired = needService;
        }
        
        public boolean getCarService()
        {
            return serviceRequired;
        }
	
	//output details 
	public void printServices()
	{
		System.out.println("Number of kilometres travelled since last service: " + kmTravelledSinceLastService);
                System.out.println("Is a service required before further rental? " + serviceRequired);
	}
			
}
