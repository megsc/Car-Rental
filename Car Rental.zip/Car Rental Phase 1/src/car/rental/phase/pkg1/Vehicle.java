/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.rental.phase.pkg1;

/**
 *
 * @author 041600253
 */
public class Vehicle 
{
    //class variables 
    int makeYear;
    String carModel, manufacturer;
    int journeyCounter = 0;
    int fuelCounter = 0;
    
    
    //array  
    Journey[] aJourney = new Journey[6];
    FuelPurchase[] PurchasedFuel = new FuelPurchase[6];   
    
    
    
    //constructor
    Vehicle()
    {
        makeYear = 0;
        carModel = "";
        manufacturer = "";
         
    }
    
	//setters and getters 
    public Vehicle(int yearMade)
    {
        this();
        makeYear = yearMade;
        
    }
        public void setYear(int mYear)
        {
            makeYear = mYear;
        }
        
        public int getYear()
        {
            return makeYear;
        }
            
    
        public void setModel(String mModel)
        {
            carModel = mModel;
        }
        
        public String getModel()
        {
            return carModel;
        }
    
    
        public void setBrand(String mBrand)
        {
            manufacturer = mBrand;
        }
        
        public String getBrand()
        {
            return manufacturer;
        }
        
        public void addJourney(Journey theJourney)
        {
            aJourney[journeyCounter] = theJourney;
            journeyCounter++;
        }
        
        Journey getJourney(int index)
        {
            return aJourney[index];
        }
        
        public void addFuel(FuelPurchase fueledUp)
        {
            PurchasedFuel[fuelCounter] = fueledUp;
            fuelCounter++;
        }
    
        FuelPurchase getFuel(int index)
        {
            return PurchasedFuel[index];
        }
        
        
        
      //output details
      public void printVehicle()
    {
 
        System.out.println("Manufacturer: " + manufacturer);
        System.out.println("Model: " + carModel);
        System.out.println("Make Year: " + makeYear);
        
        
    }
}
