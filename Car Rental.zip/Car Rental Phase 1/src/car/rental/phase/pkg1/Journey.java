package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */
public class Journey 
{
    //class variables 
    int kmTravelled;
    int dayCounter = 0;
    int kmCounter = 0;
    int serviceCounter = 0;
    
    //array
    PerDayRental[] perDay = new PerDayRental[6];
    PerKmRental[] perKm = new PerKmRental[6];
    Service[] carServices = new Service[6];
    
    
    //constructor 
    Journey()
    {
        kmTravelled = 0;
    }
    
	//setters and getters 
    public Journey(int journeyTravelled)
    {
        this();
        kmTravelled = journeyTravelled;
        
    }
    
        public void setTravelled(int mTravelled)
        {
            kmTravelled = mTravelled;
        }
        
        public int getTravelled()
        {
            return kmTravelled;
        }
    
        public void addPerDayRental(PerDayRental dayRate)
        {
            perDay[dayCounter] = dayRate;
            dayCounter++;
        }
        
        PerDayRental getDay (int index)
        {
            return perDay[index];
        }
        
        public void addPerKmRental(PerKmRental kmRate)
        {
            perKm[kmCounter] = kmRate;
            kmCounter++;
        }
        
        PerKmRental getKm (int index)
        {
            return perKm[index];
            
        }
        
        public void addService(Service serviceCar)
        {
            carServices[serviceCounter] = serviceCar;
            serviceCounter++;
        }
        
        Service getService (int index)
        {
            return carServices[index];
        }
       
    //output details 
     public void printJourney()
    {
        System.out.println("Kilometres travelled: " + kmTravelled);
    }
    
}
