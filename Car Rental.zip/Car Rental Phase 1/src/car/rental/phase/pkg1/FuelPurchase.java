
package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */
public class FuelPurchase 
{
	//class variables 
    double fuelEconomy;
    float fuelCost;
    float litresOfFuel;
    int kmTravelled;
   
    //constructors   
    FuelPurchase()
    {
        fuelEconomy = 0;
        fuelCost = 0;
        litresOfFuel = 0; 
        kmTravelled = 0;
    }
    
	//setters and getters 
    public FuelPurchase(double fuelEcon)
    {
        this();
        fuelEconomy = fuelEcon;
        
    }
        public void setKmTrav (int travel)
        {
            kmTravelled = travel;
        }
        
        public double getFuelEcon()
        {
            return fuelCost / kmTravelled * 100; 
        }
  
        
        public void setFuelCost(float gasCost)
        {
            fuelCost = gasCost; 
        }
        
        public double getFuelCost()
        {
            return fuelCost;
        }
    
        
        public void setLitresFuel(float howManyLitres)
        {
            litresOfFuel = howManyLitres;
        }
        
        public double getLitresFuel()
        {
            return litresOfFuel;
        }
        
        public double getAverageFuelCost()
        {
            return fuelCost / litresOfFuel ;
        }
    
    
    //output details
    public void printFuelPurchase()
    {
        System.out.println("Kilometres travelled required: " + litresOfFuel + " litres of fuel at a cost of: $" + fuelCost);
        System.out.println("Fuel Economy is: " + getFuelEcon() + " litres per 100 kilmotres");
        System.out.println("The average cost of fuel was: $" + getAverageFuelCost() + " per litre");
  
    }
    
    
}
