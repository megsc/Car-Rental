
package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */
public class FuelPurchase 
{
    private double fuelEconomy;
    private int fuelCost;
    private int litresOfFuel;
    private double averageCostOfFuel;
    
    FuelPurchase()
    {
        fuelEconomy = 0;
        fuelCost = 0;
        litresOfFuel = 0;
        averageCostOfFuel = 0;
        
    }
    
    public FuelPurchase(double fuelEcon)
    {
        this();
        fuelEconomy = fuelEcon;
        
    }
        public void setFuelEcon (double mFuelEcon)
        {
            fuelEconomy = mFuelEcon;
        }
        
        public double getFuelEcon()
        {
            return fuelEconomy;
        }
  
        
        public void setFuelCost(int gasCost)
        {
            fuelCost = gasCost; 
        }
        
        public int getFuelCost()
        {
            return fuelCost;
        }
    
        
        public void setLitresFuel(int howManyLitres)
        {
            litresOfFuel = howManyLitres;
        }
        
        public int getLitresFuel()
        {
            return litresOfFuel;
        }
        
        
        public void setAverageFuelCost(double averageFuel)
        {
            averageCostOfFuel = averageFuel;
        }
        
        public double getAverageFuelCost()
        {
            return averageCostOfFuel;
        }
    
    
    
    public void printFuelPurchase()
    {
        System.out.println("Kilometres travelled required: " + litresOfFuel + " litres of fuel at a cost of: $" + fuelCost);
        System.out.println("Fuel Economy is: " + fuelEconomy + " litres per 100 kilmotres");
        System.out.println("The average cost of fuel was: $" + averageCostOfFuel + " per litre");
   
    }
    
    
}
