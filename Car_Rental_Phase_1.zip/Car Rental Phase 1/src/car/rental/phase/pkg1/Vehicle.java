
package car.rental.phase.pkg1;
import java.util.Scanner;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Vehicle 
{
    private int makeYear;
    private String carModel, manufacturer;
    
    Vehicle()
    {
        makeYear = 0;
        carModel = "";
        manufacturer = "";
        
    }
    
    public Vehicle(int yearMade)
    {
        this();
        makeYear = yearMade;
        
    }
        public void setYear(int mYear)
        {
            makeYear = mYear;
        }
        
        public int getYear()
        {
            return makeYear;
        }
            
    
        public void setModel(String mModel)
        {
            carModel = mModel;
        }
        
        public String getModel()
        {
            return carModel;
        }
    
    
        public void setBrand(String mBrand)
        {
            manufacturer = mBrand;
        }
        
        public String getBrand()
        {
            return manufacturer;
        }
    
      public void printVehicle()
    {
 
        System.out.println("Manufacturer: " + manufacturer);
        System.out.println("Model: " + carModel);
        System.out.println("Make Year: " + makeYear);
        
    }
    
	  public static void main(String args[])
	  {
           
            System.out.print("Please select car type: " + "\n1.Audi " + "\n2.Jaguar " + "\n3.Mercedes-Benz  \n");
            Scanner selection = new Scanner(System.in);
            String choice = selection.nextLine();
            int menuChoice;
            menuChoice = Integer.parseInt(choice);
            
            
	
            if (menuChoice == 1)
            {
                Vehicle carOne = new Vehicle();
                carOne.setBrand("Audi");
                carOne.getBrand();
                carOne.setModel("A6");
                carOne.getModel();
                carOne.setYear(2016);
                carOne.getYear();
        
                Journey carOneB = new Journey();
                carOneB.setTravelled(150);
                carOneB.getTravelled();
                carOneB.setServices(1);
                carOneB.getServices();

                FuelPurchase carOneC = new FuelPurchase();
                carOneC.setFuelEcon(50);
                carOneC.getFuelEcon();
                carOneC.setFuelCost(62);
                carOneC.getFuelCost();
                carOneC.setLitresFuel(75);
                carOneC.getLitresFuel();
                carOneC.setAverageFuelCost(0.83);
                carOneC.getAverageFuelCost();
			
		carOne.printVehicle();
		carOneB.printJourney();
		carOneC.printFuelPurchase();
            }
            
            else if (menuChoice == 2)
            {
		Vehicle carTwo = new Vehicle();
		carTwo.setBrand("Jaguar");
		carTwo.getModel();
		carTwo.setModel("X200");
		carTwo.getModel();
		carTwo.setYear(2015);
		carTwo.getYear();
		
		Journey carTwoB = new Journey();
		carTwoB.setTravelled(250);
		carTwoB.getTravelled();
		carTwoB.setServices(2);
		carTwoB.getServices();
		
		FuelPurchase carTwoC = new FuelPurchase();
		carTwoC.setFuelCost(72);
		carTwoC.getFuelCost();
		carTwoC.setFuelEcon(32.8);
		carTwoC.getFuelEcon();
		carTwoC.setLitresFuel(82);
		carTwoC.getLitresFuel();
		carTwoC.setAverageFuelCost(0.88);
		carTwoC.getAverageFuelCost();
        
                carTwo.printVehicle();
		carTwoB.printJourney();
		carTwoC.printFuelPurchase();
            }
            
            else if(menuChoice == 3)
            {
                
		Vehicle carThree = new Vehicle();
		carThree.setBrand("Mercedes-Benz");
		carThree.getBrand();
		carThree.setModel("CL600 C200");
		carThree.getModel();
		carThree.setYear(2015);
		carThree.getYear();
		
		Journey carThreeB = new Journey();
		carThreeB.setTravelled(350);
		carThreeB.getTravelled();
		carThreeB.setServices(3);
		carThreeB.getServices();
		
		FuelPurchase carThreeC = new FuelPurchase();
		carThreeC.setFuelEcon(28.6);
		carThreeC.getFuelEcon();
		carThreeC.setFuelCost(100);
		carThreeC.getFuelCost();
		carThreeC.setLitresFuel(100);
		carThreeC.getLitresFuel();
		carThreeC.setAverageFuelCost(1.00);
		carThreeC.getAverageFuelCost();
		
		carThree.printVehicle();
		carThreeB.printJourney();
		carThreeC.printFuelPurchase();
            }
        
    
	  }
     
       
    }
    

