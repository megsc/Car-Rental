/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.rental.phase.pkg1;

/**
 *
 * @author megancarlton
 */
public class PerKmRental 
{
    int chargePerKm;
    int distancePerRental;
    
    
    PerKmRental()
    {
        chargePerKm = 5;
        distancePerRental = 0;
        
    }
    
    public PerKmRental(int journeyPerRental)
    {
        this();
        distancePerRental = journeyPerRental;
        
    }
    
    public void setRentalKm(int rentalJourney)
    {
        distancePerRental = rentalJourney;
    }
    
    public int getRentalKm()
    {
        return distancePerRental;
    }
                
    public int getChargePerKm()
    {
        return distancePerRental * chargePerKm;
    }
    
    public void printPerKmRental()
    {
        
        System.out.println("Total gross per kilometre rate charged for rental: $" + getChargePerKm());
        
    }
            
    
}
