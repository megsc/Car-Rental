/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.rental.phase.pkg1;

/**
 *
 * @author megancarlton
 */
public class PerDayRental 
{
      int totalDaysRental;
      int costPerDay;
	  int distancePerRental;
      
      PerDayRental()
      {
          totalDaysRental = 0;
          costPerDay = 150;
		  distancePerRental = 0;
          
      }

    public PerDayRental(int rentalDuration)
    {
        this();
        totalDaysRental = rentalDuration;
    }
            
    public void setRentalDays(int duration)
    {
        totalDaysRental = duration;
    }
            
    public int getRentalDays()
    {
        return totalDaysRental;
    }
    
    public int getRentalCharge()
    {
        return totalDaysRental * costPerDay;
    }
    
	public void setRentalKm(int rentalJourney)
    {
        distancePerRental = rentalJourney;
    }
    
    public int getRentalKm()
    {
        return distancePerRental;
    }
			
			
    public void printPerDayRental()
    {
        System.out.println("Car was rented for " + totalDaysRental + " days.");
        System.out.println("Total gross per day rate charged for rental: $" + getRentalCharge());
		System.out.println("Total kilometres driven over rental: " + distancePerRental);
    }
    
    
    
    
    
}
