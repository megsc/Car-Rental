package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */
public class Journey 
{
    int kmTravelled;
    
    
    Journey()
    {
        kmTravelled = 0;
        
    }
    
    public Journey(int journeyTravelled)
    {
        this();
        kmTravelled = journeyTravelled;
        
    }
    
        public void setTravelled(int mTravelled)
        {
            kmTravelled = mTravelled;
        }
        
        public int getTravelled()
        {
            return kmTravelled;
        }
    
       
    
     public void printJourney()
    {
        System.out.println("Kilometres travelled: " + kmTravelled);
        
    }
    
}
