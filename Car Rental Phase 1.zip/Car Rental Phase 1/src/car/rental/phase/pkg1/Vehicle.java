
package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Vehicle 
{
    private int makeYear;
    private String carModel, manufacturer;
    
    Vehicle()
    {
        makeYear = 0;
        carModel = "";
        manufacturer = "";
        
    }
    
    public Vehicle(int yearMade)
    {
        this();
        makeYear = yearMade;
        
    }
        public void setYear(int mYear)
        {
            makeYear = mYear;
        }
        
        public int getYear()
        {
            return makeYear;
        }
            
    
        public void setModel(String mModel)
        {
            carModel = mModel;
        }
        
        public String getModel()
        {
            return carModel;
        }
    
    
        public void setBrand(String mBrand)
        {
            manufacturer = mBrand;
        }
        
        public String getBrand()
        {
            return manufacturer;
        }
    
      public void printVehicle()
    {
 
        System.out.println("Manufacturer: " + manufacturer);
        System.out.println("Model: " + carModel);
        System.out.println("Make Year: " + makeYear);
        
    }
    
   
    
    public static void main (String[] args)
    {
        Vehicle carOne = new Vehicle();
        carOne.setModel("Audi");
        carOne.getModel();
        carOne.setModel("A6");
        carOne.getModel();
        carOne.setYear(2015);
        carOne.getYear();
        
        Journey carOneB = new Journey();
        carOneB.setTravelled(150);
        carOneB.getTravelled();
        carOneB.setServices(1);
        carOneB.getServices();
        
        FuelPurchase carOneC = new FuelPurchase();
        carOneC.setFuelEcon(50);
        carOneC.getFuelEcon();
        carOneC.setFuelCost(62);
        carOneC.getFuelCost();
        carOneC.setLitresFuel(75);
        carOneC.getLitresFuel();
        carOneC.setAverageFuelCost(0.83);
        carOneC.getAverageFuelCost();
        
        carOne.printVehicle();
        carOneB.printJourney();
        carOneC.printFuelPurchase();
        
                
        
        
    }
    
     
       
    }
    

