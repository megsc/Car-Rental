
package car.rental.phase.pkg1;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Main  {

    
	  public static void main(String args[])
	  {
           
            String[] carDets = new String[6];
            carDets[0] = "Audi";
            carDets[1] = "A6";
            carDets[2] = "Jaguar";
            carDets[3] = "X200";
            carDets[4] = "Mercedes-Benz";
            carDets[5] = "CL600 C200";
              
              
            System.out.print("Please select car type: " + "\n1.Audi " + "\n2.Jaguar " + "\n3.Mercedes-Benz  \n");
            Scanner selection = new Scanner(System.in);
            String choice = selection.nextLine();
            int menuChoice;
            menuChoice = Integer.parseInt(choice);
            
            
	
            if (menuChoice == 1)
            {
                Vehicle blue = new Vehicle();
                blue.setBrand(carDets[0]);
                blue.setModel(carDets[1]);
                blue.setYear(2016);
                
                Journey blueB1 = new Journey();
                blueB1.setTravelled(150);
                blueB1.getServices();
                blue.addJourney(blueB1);
                
                Journey blueB2 = new Journey();
                blueB2.setTravelled(110);
                blueB2.getServices();
                blue.addJourney(blueB2);
                        
                FuelPurchase blueC1 = new FuelPurchase();
                blueC1.setFuelEcon(50);
                blueC1.setFuelCost(62);
                blueC1.setLitresFuel(75);      
                blueC1.getAverageFuelCost();
                blue.addFuel(blueC1);
                              
                FuelPurchase blueC2 = new FuelPurchase();
                blueC2.setFuelEcon(50);
                blueC2.setFuelCost(57);
                blueC2.setLitresFuel(67);      
                blueC2.getAverageFuelCost();
                blue.addFuel(blueC2);
		
                PerKmRental blueD1 = new PerKmRental();
                blueD1.setRentalKm(150);
                blueD1.getChargePerKm();
                
                PerDayRental blueE2 = new PerDayRental();
                blueE2.setRentalDays(3);
                blueE2.getRentalCharge();
                
		blue.printVehicle();
		blueB1.printJourney();
		blueC1.printFuelPurchase();
                blueD1.printPerKmRental();
                
                blue.printVehicle();
                blueB2.printJourney();
                blueC2.printFuelPurchase();
                blueE2.printPerDayRental();
                
                
                
            }
            
            else if (menuChoice == 2)
            {
		Vehicle red = new Vehicle();
		red.setBrand(carDets[2]);
		red.setModel(carDets[3]);
		red.setYear(2015);
		
		Journey redB = new Journey();
		redB.setTravelled(250);
		redB.getServices();
                red.addJourney(redB);
		
		FuelPurchase redC = new FuelPurchase();
		redC.setFuelCost(72);
		redC.setFuelEcon(32.8);
		redC.setLitresFuel(82);
		redC.getAverageFuelCost();
                red.addFuel(redC);
  
                red.printVehicle();
		redB.printJourney();
		redC.printFuelPurchase();
            }
            
            else if(menuChoice == 3)
            {
                
		Vehicle green = new Vehicle();
		green.setBrand(carDets[4]);
		green.setModel(carDets[5]);
		green.setYear(2015);
		
		Journey greenB = new Journey();
		greenB.setTravelled(350);
		greenB.getServices();
                green.addJourney(greenB);
		
		FuelPurchase greenC = new FuelPurchase();
		greenC.setFuelEcon(28.6);
		greenC.setFuelCost(100);
		greenC.setLitresFuel(100);
		greenC.getAverageFuelCost();
                green.addFuel(greenC);
		
		green.printVehicle();
		greenB.printJourney();
		greenC.printFuelPurchase();
            }
        
    
	  }
     
       
    }
    

