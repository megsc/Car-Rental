
package car.rental.phase.pkg1;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Main  {

    
	  public static void main(String args[])
	  {
           
            String[] carDets = new String[6];
            carDets[0] = "Audi";
            carDets[1] = "A6";
            carDets[2] = "Jaguar";
            carDets[3] = "X200";
            carDets[4] = "Mercedes-Benz";
            carDets[5] = "CL600 C200";
              
              
            System.out.print("Please select car type: " + "\n1.Audi " + "\n2.Jaguar " + "\n3.Mercedes-Benz  \n");
            Scanner selection = new Scanner(System.in);
            String choice = selection.nextLine();
            int menuChoice;
            menuChoice = Integer.parseInt(choice);
            
            
	
            if (menuChoice == 1)
            {
                Vehicle blue = new Vehicle();
                blue.setBrand(carDets[0]);
                blue.getBrand();
                blue.setModel(carDets[1]);
                blue.getModel();
                blue.setYear(2016);
                blue.getYear();
                
                Journey blueB = new Journey();
                blueB.setTravelled(150);
                blueB.getTravelled();
                blueB.getServices();
                blue.addJourney(blueB);
                
                FuelPurchase blueC = new FuelPurchase();
                blueC.setFuelEcon(50);
                blueC.getFuelEcon();
                blueC.setFuelCost(62);
                blueC.getFuelCost();
                blueC.setLitresFuel(75);      
                blueC.getAverageFuelCost();
                blue.addFuel(blueC);
			
		blue.printVehicle();
		blueB.printJourney();
		blueC.printFuelPurchase();
            }
            
            else if (menuChoice == 2)
            {
		Vehicle red = new Vehicle();
		red.setBrand(carDets[2]);
		red.getModel();
		red.setModel(carDets[3]);
		red.getModel();
		red.setYear(2015);
		red.getYear();
		
		Journey redB = new Journey();
		redB.setTravelled(250);
		redB.getTravelled();
		redB.getServices();
                red.addJourney(redB);
		
		FuelPurchase redC = new FuelPurchase();
		redC.setFuelCost(72);
		redC.getFuelCost();
		redC.setFuelEcon(32.8);
		redC.getFuelEcon();
		redC.setLitresFuel(82);
		redC.getLitresFuel();
		redC.getAverageFuelCost();
                red.addFuel(redC);
  
                red.printVehicle();
		redB.printJourney();
		redC.printFuelPurchase();
            }
            
            else if(menuChoice == 3)
            {
                
		Vehicle green = new Vehicle();
		green.setBrand(carDets[4]);
		green.getBrand();
		green.setModel(carDets[5]);
		green.getModel();
		green.setYear(2015);
		green.getYear();
		
		Journey greenB = new Journey();
		greenB.setTravelled(350);
		greenB.getTravelled();
		greenB.getServices();
                green.addJourney(greenB);
		
		FuelPurchase greenC = new FuelPurchase();
		greenC.setFuelEcon(28.6);
		greenC.getFuelEcon();
		greenC.setFuelCost(100);
		greenC.getFuelCost();
		greenC.setLitresFuel(100);
		greenC.getLitresFuel();
		greenC.getAverageFuelCost();
                green.addFuel(greenC);
		
		green.printVehicle();
		greenB.printJourney();
		greenC.printFuelPurchase();
            }
        
    
	  }
     
       
    }
    

