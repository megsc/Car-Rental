
package car.rental.phase.pkg1;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author 041600253 Megan Carlton 
 */


public class Main  {

    
	  public static void main(String args[])
	  {
           
            String[] carDets = new String[6];
            carDets[0] = "Audi";
            carDets[1] = "A6";
            carDets[2] = "Jaguar";
            carDets[3] = "X200";
            carDets[4] = "Mercedes-Benz";
            carDets[5] = "CL600 C200";
              
              
            System.out.print("Please select car type: " + "\n1.Audi " + "\n2.Jaguar " + "\n3.Mercedes-Benz  \n");
            Scanner selection = new Scanner(System.in);
            String choice = selection.nextLine();
            int menuChoice;
            menuChoice = Integer.parseInt(choice);
            
            
			
	
            if (menuChoice == 1)
            {
                Vehicle blue = new Vehicle();
                blue.setBrand(carDets[0]);
                blue.setModel(carDets[1]);
                blue.setYear(2016);
                
                Journey blueB1 = new Journey();
                blueB1.setTravelled(210);
                blue.addJourney(blueB1);
				
                Journey blueB2 = new Journey();
                blueB2.setTravelled(110);
                blue.addJourney(blueB2);
                        
                FuelPurchase blueC1 = new FuelPurchase();
				blueC1.setFuelEcon(50);
                blueC1.setFuelCost(62);
                blueC1.setLitresFuel(75);      
                blueC1.getAverageFuelCost();
                blue.addFuel(blueC1);
                              
                FuelPurchase blueC2 = new FuelPurchase();
                blueC2.setFuelEcon(50);
                blueC2.setFuelCost(57);
                blueC2.setLitresFuel(67);      
                blueC2.getAverageFuelCost();
                blue.addFuel(blueC2);
		
                PerKmRental blueD1 = new PerKmRental();
                blueD1.setRentalKm(210);
                blueD1.getChargePerKm();
                
                PerDayRental blueE2 = new PerDayRental();
                blueE2.setRentalDays(3);
                blueE2.getRentalCharge();
				blueE2.setRentalKm(110);
				blueE2.getRentalKm();
				
				Service blueF1 = new Service();
				blueF1.setKmForService(210);
				blueF1.getService();
				
				//Service blueF2 = new Service();
				//blueF2.setKmForService(110);
				//blueF2.getService();
			    
				System.out.println("Audi Rental History: \nRental 1: ");
				blue.printVehicle();
				blueB1.printJourney();
				blueC1.printFuelPurchase();
                blueD1.printPerKmRental();
				blueF1.printServices();
                
				System.out.println("\nRental 2: ");
				
                blue.printVehicle();
                blueB2.printJourney();
                blueC2.printFuelPurchase();
                blueE2.printPerDayRental();
                //blueF2.printServices();
                
                if (blueE2.getRentalKm() > 100 & blueF1.getService() == 2)
				{
					System.out.println("WARNING: Vehicle requires service before release!");
				}
				
				else
				{
					System.out.println("Vehicle can be released for hire.");
				}
            }
            
            else if (menuChoice == 2)
            {
				Vehicle red = new Vehicle();
				red.setBrand(carDets[2]);
				red.setModel(carDets[3]);
				red.setYear(2015);

				Journey redB = new Journey();
				redB.setTravelled(502);
                red.addJourney(redB);
		
				FuelPurchase redC = new FuelPurchase();
				redC.setFuelCost(72);
				redC.setFuelEcon(32.8);
				redC.setLitresFuel(82);
				redC.getAverageFuelCost();
                red.addFuel(redC);
				
				PerDayRental redD = new PerDayRental();
				redD.setRentalDays(6);
				redD.setRentalKm(502);
				redD.getRentalKm();
				redD.getRentalCharge();
				
				Service redE = new Service();
				redE.setKmForService(502);
				redE.getService();

				
				System.out.println("Jaguar Rental History: \nRental 1: ");
                red.printVehicle();
				redB.printJourney();
				redC.printFuelPurchase();
				redD.printPerDayRental();
				redE.printServices();
				
				if (redD.getRentalKm() > 600 && redE.getService() == 5 )
				{
					System.out.println("WARNING: Vehicle requires service before release!");
				}
				
				else
				{
					System.out.println("Vehicle can be released for hire!");
				}
				
            }
            
            else if(menuChoice == 3)
            {
                
				Vehicle green = new Vehicle();
				green.setBrand(carDets[4]);
				green.setModel(carDets[5]);
				green.setYear(2015);

				Journey greenB1 = new Journey();
				greenB1.setTravelled(350);
                green.addJourney(greenB1);
				
				Journey greenB2 = new Journey();
				greenB2.setTravelled(600);
				green.addJourney(greenB2);
				
				FuelPurchase greenC1 = new FuelPurchase();
				greenC1.setFuelEcon(28.6);
				greenC1.setFuelCost(100);
				greenC1.setLitresFuel(100);
				greenC1.getAverageFuelCost();
                green.addFuel(greenC1);
		
				FuelPurchase greenC2 = new FuelPurchase();
				greenC2.setFuelEcon(28.6);
				greenC2.setFuelCost(110);
				greenC2.setLitresFuel(107);
				greenC2.getAverageFuelCost();
				green.addFuel(greenC2);
				
				PerKmRental greenD1 = new PerKmRental();
				greenD1.setRentalKm(350);
				greenD1.getChargePerKm();
				
				PerDayRental greenE2 = new PerDayRental();
				greenE2.setRentalDays(8);
				greenE2.setRentalKm(600);
				greenE2.getRentalKm();
				greenE2.getRentalCharge();
				
				Service greenF1 = new Service();
				greenF1.setKmForService(350);
				greenF1.getService();
				
				
				
				System.out.println("Mercedes-Benz Rental History: \nRental 1: ");
				green.printVehicle();
				greenB1.printJourney();
				greenC1.printFuelPurchase();
				greenD1.printPerKmRental();
				greenF1.printServices();
				
				System.out.println("\nRental 2: ");
				
				green.printVehicle();
				greenB2.printJourney();
				greenC2.printFuelPurchase();
				greenE2.printPerDayRental();
				
				if(greenE2.getRentalKm() > 100 && greenF1.getService() == 3)
				{
					System.out.println("WARNING: Vehicle requires service before release!");
				}
				
				else 
				{
					System.out.println("Vehicle can be released for hire!");
				}
            }
        
    
	  }
     
       
    }
    

