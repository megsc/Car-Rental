
package car.rental.phase.pkg1;

/**
 *
 * @author 041600253 Megan Carlton 
 */
public class FuelPurchase 
{
    private double fuelEconomy;
    private float fuelCost;
    private float litresOfFuel;
   
        
    FuelPurchase()
    {
        fuelEconomy = 0;
        fuelCost = 0;
        litresOfFuel = 0;
                
    }
    
    public FuelPurchase(double fuelEcon)
    {
        this();
        fuelEconomy = fuelEcon;
        
    }
        public void setFuelEcon (double mFuelEcon)
        {
            fuelEconomy = mFuelEcon;
        }
        
        public double getFuelEcon()
        {
            return fuelEconomy;
        }
  
        
        public void setFuelCost(float gasCost)
        {
            fuelCost = gasCost; 
        }
        
        public double getFuelCost()
        {
            return fuelCost;
        }
    
        
        public void setLitresFuel(float howManyLitres)
        {
            litresOfFuel = howManyLitres;
        }
        
        public double getLitresFuel()
        {
            return litresOfFuel;
        }
        
        
       
        public double getAverageFuelCost()
        {
            return fuelCost / litresOfFuel ;
        }
    
    
    
    public void printFuelPurchase()
    {
        System.out.println("Kilometres travelled required: " + litresOfFuel + " litres of fuel at a cost of: $" + fuelCost);
        System.out.println("Fuel Economy is: " + fuelEconomy + " litres per 100 kilmotres");
        System.out.println("The average cost of fuel was: $" + getAverageFuelCost() + " per litre");
  
    }
    
    
}
